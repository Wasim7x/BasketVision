import os
from pathlib import Path
import video_utils
from court_keypoint_detector import CourtKeypointDetector
from court_keypoint_drawer import CourtKeypointDrawer
from tactical_view_convertor import TacticalViewConverter



def main():
    video_path = "D:\\project\\BasketVision\\data\\input-videos\\Video Project 2.mp4"
    court_image_path = "images\\basketball_court.png"

    video_frames = video_utils.read_video(video_path)
    court_keypoint_detector = CourtKeypointDetector(model_path="models\\best (2).pt")
    detected_court_keypoint = court_keypoint_detector.get_court_keypoints(video_frames,
                                                                read_from_stub=False,
                                                                stub_path="stubs\\court_keypoints_stub.pkl")
    tactical_view_converter = TacticalViewConverter(court_image_path="D:\\project\\BasketVision\\images\\basketball_court.png")
    court_keypoint = tactical_view_converter.validate_keypoints(detected_court_keypoint)    
    # tactical_player_positions = tactical_view_converter.transform_players_to_tactical_view(court_keypoint, player_tracks)                                                        

    
    #draw and save detected court keypoints on first frame
    output_video_frames = video_frames.copy()
    court_keypoint_drawer = CourtKeypointDrawer()
    output_video_frames = court_keypoint_drawer.draw(output_video_frames,
                                                    detected_court_keypoint)
   
    print(detected_court_keypoint)

    video_name = os.path.splitext(os.path.basename(video_path))[0]
    output_path = os.path.join("output","keypoint", f"{video_name}_output.mp4")
    video_utils.save_video(output_video_frames, output_path)

    

if __name__ == "__main__":
    main()
   
